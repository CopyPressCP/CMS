tinyMCE.addI18n('en.SCAYT',{
	desc: 'SpellCheckAsYouType',
	SCAYT_long_name:'SpellCheckAsYouType'
});
